﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHigherLowerGame
{
    public class Question
    {
        public int Id;
        public string Text;
        public int correctAnswer;
    }
}
